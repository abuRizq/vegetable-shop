// import { NextResponse } from "next/server";
// import { cookies } from "next/headers";
// import type { User } from "@/app/types/auth";




// const BaseUrl = process.env.NEXT_PUBLIC_API_URL;

// export async function GET(token:string) {
//     try {
//         // 1. Check for token
//         // const token = (await cookies()).get("at")?.value;
//         // if (!token) {
//         // return
//         // }

//         const data = await fetch(`${BaseUrl}/auth/me`, {
//             headers: {
//                 Authorization: `Bearer ${token}`,
//                 'Content-Type': 'application/json'
//             },
//             cache: "no-store",
//         });

//         // 4. Handle upstream response
//         // try {
//         //   cosnt body = await data.json();
//         // } catch (jsonError) {
//         //     return NextResponse.json<ApiResponse<User>>(
//         //         {
//         //             success: false,
//         //             data: null,
//         //             error: "Invalid response from authentication service",
//         //             meta: null
//         //         },
//         //         { status: 502 }
//         //     );
//         // }

//         // 5. Check upstream status and body structure
//         // if (!upstream.ok) {
//         //     const errorMessage = body?.error || body?.message || upstream.statusText || "Authentication failed";
//         //     return NextResponse.json<ApiResponse<User>>(
//         //         {
//         //             success: false,
//         //             data: null,
//         //             error: errorMessage,
//         //             meta: null
//         //         },
//         //         { status: upstream.status }
//         //     );
//         // }

//         // 6. Validate response structure
//         if (!body || body.success === false) {
//             const errorMessage = body?.error || "Authentication service returned an error";
//             return NextResponse.json<ApiResponse<User>>(
//                 {
//                     success: false,
//                     data: null,
//                     error: errorMessage,
//                     meta: null
//                 },
//                 { status: 401 }
//             );
//         }

//         // 7. Validate user data
//         if (!body.data) {
//             return NextResponse.json<ApiResponse<User>>(
//                 {
//                     success: false,
//                     data: null,
//                     error: "User data not found",
//                     meta: null
//                 },
//                 { status: 404 }
//             );
//         }

//         // 8. Return success response
//         return NextResponse.json<ApiResponse<User>>(
//             {
//                 success: true,
//                 data: body.data,
//                 error: null, // Don't comment this out - include it for consistency
//                 meta: body.meta || null,
//             },
//             { status: 200 }
//         );

//     } catch (error) {
//         // 9. Handle unexpected errors
//         console.error('Unexpected error in /api/me:', error);
   
//     }
// }