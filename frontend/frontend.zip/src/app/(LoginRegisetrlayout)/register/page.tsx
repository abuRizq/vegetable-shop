import { RegisterForm } from '@/app/_Components/register/RegisterForm'
import React from 'react'

function page() {
    return (
        <div className="h-screen w-full">
            <RegisterForm />
        </div>
    )
}

export default page