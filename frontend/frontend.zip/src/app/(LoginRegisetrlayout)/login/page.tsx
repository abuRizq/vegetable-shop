"use client"

import { LoginForm } from '@/app/_Components/login/LoginForm'
import React from 'react'

function page() {
    return (
        <div className="h-screen w-full">
            <LoginForm />
        </div>
    )
}

export default page