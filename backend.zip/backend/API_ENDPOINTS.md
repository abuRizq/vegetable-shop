# VeggieShop API Endpoints Map

> Generated from `modules/contracts/http/openapi/*.yaml`. Replace placeholders like `{id}` before use.

_Total endpoints discovered:_ **0**


| Method | Path | Tag(s) | Summary | Spec File |
|---|---|---|---|---|
